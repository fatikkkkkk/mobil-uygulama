import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Login from './screens/Login';
import Home from './screens/Home';
import Weather from './screens/Weather';

const Stack = createNativeStackNavigator();

export default function App() {

const options = {
  headerStyle: {
    backgroundColor: 'navy'
  },
  headerTintColor: '#fff',
  headerTitleStyle:{
    fontSize: 14
  },
  headerTitleAlign:'center'
}
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="login">
        <Stack.Screen name="login" component={Login} options={{...options,title:'Giriş'}}/>
        <Stack.Screen name="home" component={Home} options={{...options,title:'Ana Ekran'}}/>
        <Stack.Screen name="weather" component={Weather} options={{...options,title:'Hava Durumu'}}/>
      </Stack.Navigator>
    </NavigationContainer>      
  );
}

