import { useEffect, useState } from 'react';
import { StyleSheet, View} from 'react-native';
import MapView, { Marker, Polyline } from 'react-native-maps';
import MapViewDirections from 'react-native-maps-directions';
import * as Location from 'expo-location';


export default MapScreen = () => {
  const [origin, setOrigin] = useState({
    latitude: 37.034716,
    longitude: 37.317905,
  });

  const [destination, setDestination] = useState({
    latitude: 37.051157,
    longitude: 37.320741,
  });

  useEffect(
    () => {
      getLocationPermission();
    },
    []
  );
  async function getLocationPermission() {
    let { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') {
      alert('Permission denied');
      return;
    }
    let location = await Location.getCurrentPositionAsync({});
    const current = {
      latitude: location.coords.latitude,
      longitude: location.coords.longitude,
    };
    setOrigin(current);
  }

  return(
    <View style={styles.container}>     
      <MapView style={styles.map}
        initialRegion={{
          latitude: origin.latitude,
          longitude: origin.longitude,
          latitudeDelta: 0.03,
          longitudeDelta:0.03
        }}
      >
        <Marker 
          draggable
          coordinate={ origin }
          onDragEnd={ (direction)=> setOrigin(direction.nativeEvent.coordinate)
          }
          image={ carImage }
        />
        <Marker 
          draggable
          coordinate={ destination }
          onDragEnd={ (direction)=> setDestination(direction.nativeEvent.coordinate)}
        />
        <MapViewDirections
          origin={origin}
          destination={destination}
          strokeColor="black"
          strokeWidth={5}
                   apikey={"AIzaSyDPN4pKI-H3H52nY-2pW589AS7U21ztSwE"}

        />
      </MapView>
    </View>
  );

}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  map: {
    width: '100%',
    height: '100%'
  }
});