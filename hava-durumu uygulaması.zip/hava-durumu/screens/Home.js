import { useEffect, useLayoutEffect } from 'react';
import { Text, View, StyleSheet, Button, TouchableOpacity } from 'react-native';
import { AntDesign } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default Home = ({ navigation, route }) => {
  const vars = route.params;

  useLayoutEffect(() => {
    navigation.setOptions({
      title: 'Merhaba, ' + vars.username,
      headerBackVisible: false,
      headerRight: () => (
        <TouchableOpacity>
          <AntDesign name="logout" size={18} color="white" onPress={logout} />
        </TouchableOpacity>
      ),
    });
  }, []);

  const logout = async () => {
    try {
      await AsyncStorage.removeItem('loginData');
      navigation.navigate('login');
    } catch (e) {
      // remove error
    }    
  };


  return (
    <View style={styles.container}>
      <Text style={styles.title}>Ana Ekran</Text>
      <Button
        title="Hava Durumu"
        onPress={() => navigation.navigate('weather')}

       
      />
      
      <Button
        title="Harita"
        onPress={() => navigation.navigate('')}
      />
      
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#009186',
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 24,
  },
});
