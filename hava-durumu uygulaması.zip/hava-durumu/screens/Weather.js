import { useState, useEffect } from 'react';

import {
  Text,
  SafeAreaView,
  StyleSheet,
  View,
  Button,
  TextInput,
  Image,
  ActivityIndicator
} from 'react-native';
import axios from 'axios';
import * as Location from 'expo-location';

export default function App() {
  const [value, setValue] = useState('');
  const [weatherData, setWeatherData] = useState("");
  const [loading, setLoading] = useState(false);
  
  const getWeather = (type, data) => {
    setLoading(true);
    let url = "";
    if( type === 'location'){
      url = "http://api.openweathermap.org/data/2.5/weather?lat="+data.coords.latitude+"&lon="+data.coords.longitude+"&units=metric&appid=fa31b0a8e81dcc4a5cd5dcb76b203652";

    }
    else{
      url = "http://api.openweathermap.org/data/2.5/weather?q="+data+"&units=metric&appid=fa31b0a8e81dcc4a5cd5dcb76b203652";
    }

    axios
      .get(url)
      .then((response) => {
        setWeatherData(response.data);
        setLoading(false);
        console.log(response.data);
      })
      .catch((error) => console.log(error));
  };

  const buttonPress = () => {
    if (value !== '') {
      getWeather("search",value);
    }
  };

  const getLocation = async () => {
    let { status } = await Location.requestForegroundPermissionsAsync();
    if(status !== 'granted'){
      return;
    }
    let location = await Location.getCurrentPositionAsync({});
    console.log(location);
    getWeather('location', location);      
  }

  useEffect(
    () => {
      getWeather('search','Gaziantep')
    }
    ,
    []
  );
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.row}>
        <TextInput
          style={styles.input}
          onChangeText={(val) => setValue(val)}
          value={value}
          placeholder="Şehir Adını Yazın"
        />
        <Button title="Bul" onPress={buttonPress} />
      </View>
      {
        loading ? 
        <View style={styles.row}>
          <ActivityIndicator size="large" />
        </View>
        :
         weatherData ? 
          <View>
            <View style={styles.row}>
              <Text style={styles.title}>{weatherData.name}</Text>
            </View>
            <View style={styles.row}>
              <Image 
              source={{
                uri: 'https://openweathermap.org/img/wn/'+weatherData.weather[0].icon+'@4x.png'
              }}
              style={{width:200, height:200}}
              />
            </View>
            <View style={styles.row}>
              <Text style={styles.title}>{weatherData.main.temp.toFixed(0)} °C</Text>
            </View>
            <View style={styles.row}>
              <Text style={styles.title}>{weatherData.weather[0].description}</Text>
            </View>
          </View>
          : 
          <View style={styles.row}>
            <Text>Sonuç Bulunamadı</Text>
          </View>
      }
      <Button title="Konum Kullan" onPress={ ()=>getLocation()} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ecf0f1',
    padding: 10,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginVertical: 10,
  },
  title: {
    fontSize: 32,
  },
  input: {
    height: 40,
    margin: 6,
    borderWidth: 1,
    borderRadius: 4,
    borderColor: 'navy',
    padding: 10,
    width: '60%',
  },
});
