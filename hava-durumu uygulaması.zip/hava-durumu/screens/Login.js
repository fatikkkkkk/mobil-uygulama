import { useState, useEffect } from 'react';
import {
  Text,
  View,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Alert,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default Login = ({ navigation }) => {
  const [username, setUsername] = useState();
  const [password, setPassword] = useState();

  useEffect(() => {
    getData();
  }, []);

  const onPress = () => {
    if (username === 'admin' && password === '123456') {
      storeData({
        username: username,
        password: password,
      });
      navigation.navigate('home', {
        username: 'admin',
      });
    } else {
      Alert.alert('Uyarı', 'Giriş Hatası', [
        {
          text: 'Tamam',
          onPress: () => console.log('Ok'),
        },
      ]);
    }
  };

  const storeData = async (value) => {
    try {
      const jsonValue = JSON.stringify(value);
      await AsyncStorage.setItem('loginData', jsonValue);
    } catch (e) {
      // saving error
    }
  };

  const getData = async () => {
    try {
      const jsonValue = await AsyncStorage.getItem('loginData');
      if (jsonValue != null) {
        const value = JSON.parse(jsonValue);
        if (value.username === 'admin' && value.password === '12345') {
          navigation.navigate('home', {
            username: 'admin',
          });
        }
      }
    } catch (e) {
      // error reading value
    }
  };

  return (
    <View style={styles.container}>
    
      <Text style={styles.title}>Üye Giriş Ekranı</Text>
      <View>
        <TextInput
          placeholder="Kullanıcı Adı"
          style={styles.input}
          autoCapitalize="none"
          onChangeText={setUsername}
        />
        <TextInput
          placeholder="Parola"
          style={styles.input}
          autoCapitalize="none"
          secureTextEntry
          onChangeText={setPassword}
        />
      </View>
      <TouchableOpacity
        style={styles.button}
        activeOpacity={0.7}
        onPress={onPress}>
        <Text style={styles.text}>Giriş Yap</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    paddingTop: 60,
  },
  title: {
    fontSize: 24,
    paddingBottom: 30,
  },
  input: {
    padding: 14,
    borderWidth: 1,
    borderRadius: 6,
    borderColor: '#888',
    width: 300,
    marginVertical: 20,
  },
  button: {
    padding: 14,
    borderWidth: 1,
    borderRadius: 6,
    borderColor: '#888',
    width: 300,
    marginVertical: 20,
    alignItems: 'center',
    backgroundColor: 'blue',
  },
  text: {
    color: '#fff',
  },
});
